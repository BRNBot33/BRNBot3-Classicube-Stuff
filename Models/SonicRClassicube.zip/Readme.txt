Model made by BRNBot3, textures adapted by BRNBot3.

Thanks to Sega and Sonic Team for making the original Sonic R model.