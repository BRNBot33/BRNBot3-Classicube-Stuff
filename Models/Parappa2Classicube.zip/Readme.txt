Model made by BRNBot3, textures ripped by BRNBot3.

All of this is possible thanks to the original staff of Parappa The Rapper 2.